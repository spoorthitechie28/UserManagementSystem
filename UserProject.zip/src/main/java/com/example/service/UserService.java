package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.User;
import com.example.repository.UserRepository;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;

    // CREATE
    public User saveUser(User user) {
        return repository.save(user);
    }

    // READ ALL
    public List<User> getAllUsers() {
        return repository.findAll();
    }

    // READ BY ID
    public User getUserById(int id) {
        return repository.findById(id).orElse(null);
    }

    // UPDATE
    public User updateUser(User user) {
        return repository.save(user);
    }

    // DELETE
    public String deleteUser(int id) {
        repository.deleteById(id);
        return "User deleted successfully";
    }
}
