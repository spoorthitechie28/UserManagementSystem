package com.example.dto;

import jakarta.validation.constraints.*;

public class UserDto {

    @NotBlank(message = "Name cannot be empty")
    private String name;

    @Email(message = "Invalid email format")
    private String email;

    @Pattern(regexp = "^\\d{10}$", message = "Mobile must be 10 digits")
    private String mobile;

    @Min(value = 18, message = "Age must be at least 18")
    @Max(value = 60, message = "Age must not exceed 60")
    private int age;

    @NotBlank(message = "Nationality cannot be empty")
    private String nationality;

    // GETTERS
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getMobile() { return mobile; }
    public int getAge() { return age; }
    public String getNationality() { return nationality; }

    // SETTERS
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    public void setAge(int age) { this.age = age; }
    public void setNationality(String nationality) { this.nationality = nationality; }
}