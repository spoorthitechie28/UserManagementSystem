package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.Optional;
import com.example.dto.UserDto;
import org.springframework.stereotype.Service;

import com.example.entity.User;
import com.example.repository.UserRepository;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;
    
    public User saveUser(UserDto userDto) {

        User user = new User();   // create empty object

        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setMobile(userDto.getMobile());
        user.setAge(userDto.getAge());
        user.setNationality(userDto.getNationality());

        return repository.save(user);
    }

    // READ ALL
    public List<User> getAllUsers() {
        return repository.findAll();
    }

    // READ BY ID
    public Optional<User> getUserById(int id) {
        return repository.findById(id);
    }

    // UPDATE
    public User updateUser(User user) {
        return repository.save(user);
    }

    // DELETE
    public String deleteUser(int id) {
        repository.deleteById(id);
        return "User deleted successfully";
    }
}
