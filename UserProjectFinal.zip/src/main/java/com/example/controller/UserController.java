package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;

import com.example.dto.UserDto;
import org.springframework.web.bind.annotation.*;

import com.example.entity.User;
import com.example.service.UserService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService service;

    // CREATE
    @PostMapping
   public User saveUser(@RequestBody @Valid UserDto userDto) {
    	return service.saveUser(userDto);
    }

    // READ ALL
    @GetMapping
    public List<User> getAll() {
        return service.getAllUsers();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public User getUser(@PathVariable int id) {
        return service.getUserById(id).orElse(null);
    }

    // UPDATE
   @PutMapping("/update")
    public User updateUser(@RequestBody User user) {
        return service.updateUser(user);
    }

    // DELETE
    @DeleteMapping("/delete/{id}")
   public String deleteUser(@PathVariable int id) {
        return service.deleteUser(id);
    }
    
}